﻿using Chronolibris.Application.Handlers.Reviews;
using Chronolibris.Application.Interfaces;
using Chronolibris.Application.Requests.Reviews;
using Chronolibris.Domain.Entities;
using Chronolibris.Domain.Exceptions;
using Chronolibris.Domain.Interfaces.Repository;
using Chronolibris.Domain.Models;
using FluentAssertions;
using Moq;

namespace ChronolibrisServer.Tests.Reviews
{
    public class CreateReviewHandlerTests
    {
        private readonly Mock<IUnitOfWork> _unitOfWorkMock;
        private readonly Mock<IReviewRepository> _reviewRepoMock;
        private readonly Mock<IBookRepository> _bookRepoMock;
        private readonly Mock<IIdentityService> _identityServiceMock;

        private readonly long userId = 1;
        private readonly long bookId = 1;

        public CreateReviewHandlerTests()
        {
            _unitOfWorkMock = new Mock<IUnitOfWork>();
            _reviewRepoMock = new Mock<IReviewRepository>();
            _bookRepoMock = new Mock<IBookRepository>();
            _identityServiceMock = new Mock<IIdentityService>();

            _identityServiceMock.Setup(i => i.IsUserActiveAsync(It.IsAny<long>())).ReturnsAsync(true);
            _unitOfWorkMock.Setup(u => u.Reviews).Returns(_reviewRepoMock.Object);
            _unitOfWorkMock.Setup(u => u.Books).Returns(_bookRepoMock.Object);
        }

        private CreateReviewCommand BuildCommand(string? text = "Отличная книга", short score = 5)
        {
            return new CreateReviewCommand(bookId, userId, text,score);
        }

        private void SetupReview(ReviewDetailsWithVote? review)
        {
            _reviewRepoMock
                .Setup(r => r.GetActiveByUserAndBookAsync(userId, bookId, It.IsAny<CancellationToken>()))
                .ReturnsAsync(review);
        }

        private void SetupReviewCreating(long assignedId)
        {
            _unitOfWorkMock.Setup(u => u.SaveChangesAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(1);
            _reviewRepoMock.Setup(r => r.AddAsync(It.IsAny<Review>(), It.IsAny<CancellationToken>()))
                .Callback<Review, CancellationToken>((review, ct) =>
                {
                    review.Id = assignedId;
                })
                .Returns(Task.CompletedTask);
        }

        private void SetupBook(bool isReviewable = true, bool isAvailable = true)
        {
            _bookRepoMock
                .Setup(r => r.GetByIdAsync(bookId, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new Book
                {
                    Id = bookId,
                    IsReviewable = isReviewable,
                    IsAvailable = isAvailable,
                    Title = "Название книги",
                    Description = "Описание книги",
                    CountryId = 1,
                    LanguageId = 1,
                    CreatedAt = DateTime.UtcNow,
                    CoverPath = ""
                });
        }

        private CreateReviewHandler CreateHandler()
        {
            return new CreateReviewHandler(_unitOfWorkMock.Object, _identityServiceMock.Object);
        }

        [Fact]
        public async Task Handle_ExistingReview_ThrowsConflict()
        {
            //_reviewRepoMock
            //    .Setup(r => r.GetActiveByUserAndBookAsync(userId, bookId, It.IsAny<CancellationToken>()))
            //    .ReturnsAsync(new ReviewDetailsWithVote());
            SetupReview(new ReviewDetailsWithVote());

            var act = () => CreateHandler().Handle(BuildCommand(), CancellationToken.None);

            await act.Should().ThrowAsync<ChronolibrisException>()
                .Where(e => e.ErrorType == ErrorType.Conflict);

            _bookRepoMock.Verify(
                r => r.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Handle_BookNotAvailable_ThrowsNotFound()
        {
            SetupReview(null);
            SetupBook(true, false);

            var act = () => CreateHandler().Handle(BuildCommand(), CancellationToken.None);

            await act.Should().ThrowAsync<ChronolibrisException>()
                .Where(e => e.ErrorType == ErrorType.NotFound);
        }

        [Fact]
        public async Task Handle_BookNotReviewable_ThrowsNotFound()
        {
            SetupReview(null);
            SetupBook(false, true);

            var act = () => CreateHandler().Handle(BuildCommand(), CancellationToken.None);

            await act.Should().ThrowAsync<ChronolibrisException>()
                .Where(e => e.ErrorType == ErrorType.NotFound);
        }

        [Fact]
        public async Task Handle_ValidRequest_ReturnsSuccess()
        {
            SetupReview(null);
            SetupBook(true, true);
            long expectedId = 17;
            SetupReviewCreating(expectedId);

            var result = await CreateHandler().Handle(BuildCommand(), CancellationToken.None);

            result.Should().Be(expectedId);
        }

    }
}
