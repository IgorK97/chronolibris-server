﻿using System.ComponentModel.DataAnnotations;

namespace ChronolibrisWeb.InputModels
{
    public record UpdateShelfInputModel(
        [MaxLength(256)]string Name);

}
