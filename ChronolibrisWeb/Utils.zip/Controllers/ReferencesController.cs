﻿using Chronolibris.Application.Models;
using Chronolibris.Application.Requests.References;
using Chronolibris.Domain.Models;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ChronolibrisWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReferencesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ReferencesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("roles")]
        public async Task<ActionResult<IEnumerable<RoleDetails>>> GetPersonRoles()
        {
            var query = new GetRoleDetailsQuery();

            var roles = await _mediator.Send(query);

            return Ok(roles);
        }

        [HttpGet("languages")]
        public async Task<ActionResult<IEnumerable<LanguageDto>>> GetAllLanguages(CancellationToken cancellationToken)
        {
            var query = new GetAllLanguagesQuery();
            var languages = await _mediator.Send(query, cancellationToken);
            return Ok(languages);
        }

        [HttpGet("languages/{id}")]
        public async Task<ActionResult<LanguageDto>> GetLanguageById(long id, CancellationToken cancellationToken)
        {
            var query = new GetLanguageByIdQuery(id);
            var language = await _mediator.Send(query, cancellationToken);

            return Ok(language);
        }

        [Authorize(Roles ="admin")]
        [HttpPost("languages")]
        public async Task<ActionResult<long>> CreateLanguage([FromBody] CreateLanguageRequest request, CancellationToken cancellationToken)
        {

            var command = new CreateLanguageCommand(request.Name);
            var id = await _mediator.Send(command, cancellationToken);

            return Ok(id);
        }

        [Authorize(Roles ="admin")]
        [HttpPut("languages/{id}")]
        public async Task<ActionResult> UpdateLanguage(long id, [FromBody] UpdateLanguageRequest request, CancellationToken cancellationToken)
        {

            var command = new UpdateLanguageCommand(request.Id, request.Name);
            var result = await _mediator.Send(command, cancellationToken);

            return NoContent();
        }


        [Authorize(Roles ="admin")]
        [HttpDelete("languages/{id}")]
        public async Task<ActionResult> DeleteLanguage(long id, CancellationToken cancellationToken)
        {
            var command = new DeleteLanguageCommand(id);
            var result = await _mediator.Send(command, cancellationToken);

            return NoContent();
        }

        [HttpGet("countries")]
        public async Task<ActionResult<IEnumerable<CountryDto>>> GetAllCountries(CancellationToken cancellationToken)
        {
            var query = new GetAllCountriesQuery();
            var countries = await _mediator.Send(query, cancellationToken);
            return Ok(countries);
        }


        [HttpGet("countries/{id}")]
        public async Task<ActionResult<CountryDto?>> GetCountryById(long id, CancellationToken cancellationToken)
        {
            var query = new GetCountryByIdQuery(id);
            var country = await _mediator.Send(query, cancellationToken);

            return Ok(country);
        }


        [Authorize(Roles ="admin")]
        [HttpPost("countries")]
        public async Task<ActionResult<long>> CreateCountry([FromBody] CreateCountryRequest request, CancellationToken cancellationToken)
        {

            var command = new CreateCountryCommand(request.Name);
            var id = await _mediator.Send(command, cancellationToken);

            return Ok(id);
        }


        [Authorize(Roles ="admin")]
        [HttpPut("countries/{id}")]
        public async Task<ActionResult> UpdateCountry(long id, [FromBody] UpdateCountryRequest request, CancellationToken cancellationToken)
        {
            var command = new UpdateCountryCommand(request.Id, request.Name);
            var result = await _mediator.Send(command, cancellationToken);

            return NoContent();
        }


        [Authorize(Roles ="admin")]
        [HttpDelete("countries/{id}")]
        public async Task<ActionResult> DeleteCountry(long id, CancellationToken cancellationToken)
        {
            var command = new DeleteCountryCommand(id);
            var result = await _mediator.Send(command, cancellationToken);

            return NoContent();
        }


        [HttpGet("formats")]
        public async Task<ActionResult<IEnumerable<FormatDto>>> GetAllFormats(CancellationToken cancellationToken)
        {
            var query = new GetAllFormatsQuery();
            var formats = await _mediator.Send(query, cancellationToken);
            return Ok(formats);
        }
    }
}
