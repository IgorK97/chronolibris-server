﻿using System.Security.Claims;
using Chronolibris.Application.Requests.Reviews;
using Chronolibris.Application.Requests.Users;
using ChronolibrisWeb.InputModels;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace ChronolibrisWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ReviewsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{bookId}")]
        public async Task<IActionResult> GetReviews(long bookId, long? lastId, int limit=20)
        {
            long? userId = null;
            if (!TryGetUserId(out var tryUserId))
                userId = null;
            else
            {
                userId = tryUserId;
            }

            if (limit < 1) limit = 20;
            else if (limit > 20) limit = 20;

            var reviews = await _mediator.Send(new GetReviewsQuery(bookId, lastId, limit, userId));
            return Ok(reviews);
        }

        [Authorize(Roles ="reader")]
        [HttpGet("my/{bookId}")]
        public async Task<IActionResult> GetMyReview(long bookId)
        {
            if (!TryGetUserId(out var userId))
                return Unauthorized();

            var review = await _mediator.Send(new GetUserReviewForBookQuery(bookId, userId));

            //if (review == null) return NotFound();

            return Ok(review);
        }

        private bool TryGetUserId(out long userId)
        {
            var claim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return long.TryParse(claim, out userId);
        }

        [Authorize(Roles ="reader")]
        [HttpPost]
        [EnableRateLimiting("ratings")]
        public async Task<IActionResult> CreateReview(CreateReviewInputModel request)
        {
            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!long.TryParse(userIdClaim, out var userId))
                return Unauthorized();
            var command = new CreateReviewCommand(request.BookId, userId, request.ReviewText, (short)request.Score);
            var reviewId = await _mediator.Send(command);
            return Ok(reviewId);
        }

        [Authorize(Roles ="reader")]
        [HttpPut("{reviewId}")]
        public async Task<IActionResult> UpdateReview(long reviewId, UpdateReviewInputModel request)
        {
            if (!TryGetUserId(out var userId)) return Unauthorized();

            var command = new UpdateReviewCommand(reviewId, userId, request.ReviewText, request.Score);
            await _mediator.Send(command);
            return NoContent();
        }

        [Authorize]
        [HttpDelete("{reviewId}")]
        public async Task<IActionResult> DeleteReview(long reviewId)
        {
            if (!TryGetUserId(out var userId)) return Unauthorized();

            await _mediator.Send(new DeleteReviewCommand(reviewId, userId));
            return NoContent();
        }

        [Authorize(Roles ="reader")]
        [HttpPost("rate")]
        [EnableRateLimiting("ratings")]
        public async Task<IActionResult> RateReview(RateReviewInputModel request)
        {
            if (!TryGetUserId(out var userId)) return Unauthorized();

            var result = await _mediator.Send
                (new RateReviewCommand(request.ReviewId, userId, request.Score));

            return Ok(result);
        }
    }
}
