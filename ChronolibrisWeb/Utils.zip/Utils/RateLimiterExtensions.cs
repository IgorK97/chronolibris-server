﻿using System.Security.Claims;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace ChronolibrisWeb.Utils
{
    public static class RateLimiterExtensions
    {
        public static void AddChronolibrisRateLimiter(this RateLimiterOptions
            options)
        {
            options.OnRejected = async (context, token) =>
            {
                context.HttpContext.Response.StatusCode = 429;
                context.HttpContext.Response.ContentType = "application/json";

                await context.HttpContext.Response.WriteAsJsonAsync(new ProblemDetails
                {
                    Status = 429,
                    Title = "Слишком много запросов",
                    Detail = "Превышен лимит запросов. Попробуйте позже.",
                    Instance = context.HttpContext.Request.Path
                }, cancellationToken: token);
            };
            options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
            {
                //запись должна упроститься при настройке конфиге форвардед опшионс

                var ipAddress = httpContext.Connection.RemoteIpAddress?.ToString()
                                    ?? "unknown";

                //var ipAddress = httpContext.Request.Headers["X-Forwarded-For"]
                //                .FirstOrDefault()?.Split(',').FirstOrDefault()?.Trim()
                //                ?? httpContext.Connection.RemoteIpAddress?.ToString()
                //                ?? "unknown";

                return RateLimitPartition.GetFixedWindowLimiter(
                    partitionKey: ipAddress,
                    factory: _ => new FixedWindowRateLimiterOptions
                    {
                        PermitLimit = 20,           
                        Window = TimeSpan.FromSeconds(1),
                        QueueLimit = 0              // без очереди (сразу блокировать)
                    });
            });
            AddUserPolicy(options, "one", 1, 0);
            AddUserPolicy(options, "comments", 5, 60);
            AddUserPolicy(options, "ratings", 20, 60);
            AddUserPolicy(options, "reports", 1, 60);
        }

        private static void AddUserPolicy(RateLimiterOptions options,
            string name, int permitLimit, int secondsCount)
        {
            options.AddPolicy(name, httpContext =>
            {
                var ipAddress = httpContext.Connection.RemoteIpAddress?.ToString()
                                    ?? "unknown";

                //var ipAddress = httpContext.Request.Headers["X-Forwarded-For"]
                //                .FirstOrDefault()?.Split(',').FirstOrDefault()?.Trim()
                //                ?? httpContext.Connection.RemoteIpAddress?.ToString()
                //                ?? "unknown";

                var userId = httpContext.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var key = userId != null ? $"{name}:user:{userId}"
                : $"{name}:ip:{ipAddress}";

                //var userId = httpContext.User.FindFirst(ClaimTypes.NameIdentifier)!.Value;
                //var key = $"{name}:user:{userId}";
                if (secondsCount <= 0)
                {
                    return RateLimitPartition.GetConcurrencyLimiter
                    (key, _ => new ConcurrencyLimiterOptions
                    {
                        PermitLimit = permitLimit,
                        QueueLimit = 0,

                    });
                }
                return RateLimitPartition.GetSlidingWindowLimiter
                (key, _ => new SlidingWindowRateLimiterOptions
                {
                    PermitLimit = permitLimit,
                    Window = TimeSpan.FromSeconds(secondsCount),
                    SegmentsPerWindow = 2,
                    QueueLimit = 0
                });
            });
        }
    }
}