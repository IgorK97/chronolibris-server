﻿using Chronolibris.Domain.Models;
using MediatR;

namespace Chronolibris.Application.Requests.Reports
{
    public record GetReportsQuery(
        long ModeratorId,
        long? LastTargetId,
        long? LastTargetTypeId,
        //long? LastReportTypeId,
        int Count,
        bool TargetTypeFilter,
        //bool ReportTypeFilter,
        bool ReportStatusFilter,
        long? ReportStatusId,
        DateTime? LastDate):IRequest<GetReportsResponse>;

    public record GetTargetInfoQuery(
        long TargetId,
        long TargetTypeId) : IRequest<GetTargetInfoResponse?>;

    public record GetTargetReportsQuery(
        long TargetId,
        long TargetTypeId,
        long ReasonTypeId,
        int Count,
        long? LastReportId):IRequest<GetTargetReportsResponse>;

    
}
