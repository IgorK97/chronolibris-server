﻿using Chronolibris.Domain.Models;
using MediatR;

namespace Chronolibris.Application.Requests.Reports
{
    public record CreateReportCommand(
         long TargetId,
         long TargetTypeId,
         long ReasonTypeId,
         string Description,
         long UserId) : IRequest<CreateReportResult>;

    public record CreateReportResult(bool Success, string? Error);

    public record CreateModerationTaskCommand(
        long TargetId,
        long TargetTypeId,
        long ModeratorId) : IRequest<CreateModerationTaskResponse>;

    public record ResolveTaskCommand(
        long TaskId,
        bool Resolution,
        long ModeratorId, string Comment):IRequest<TaskResolutionResponse>;

}
