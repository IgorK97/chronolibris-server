﻿using Chronolibris.Application.Requests.Reviews;
using Chronolibris.Domain.Exceptions;
using Chronolibris.Domain.Interfaces.Repository;
using MediatR;

namespace Chronolibris.Application.Handlers.Reviews
{
    public class DeleteReviewCommandHandler : IRequestHandler<DeleteReviewCommand, Unit>
    {
        private readonly IUnitOfWork _uow;

        public DeleteReviewCommandHandler(IUnitOfWork uow) => _uow = uow;

        public async Task<Unit> Handle(DeleteReviewCommand cmd, CancellationToken ct)
        {
            var review = await _uow.Reviews.GetByIdAsync(cmd.ReviewId, ct);
            if (review is null || review.DeletedAt!=null) return Unit.Value;

            if (review.UserId != cmd.UserId)
                throw new ChronolibrisException("Нет доступа", ErrorType.Forbidden);

            review.DeletedAt = DateTime.UtcNow;
            review.IsDeleted = true;

            await _uow.SaveChangesAsync(ct);
            return Unit.Value;
        }
    }
}
