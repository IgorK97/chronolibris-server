﻿using Chronolibris.Application.Requests.Shelves;
using Chronolibris.Domain.Exceptions;
using Chronolibris.Domain.Interfaces.Repository;
using MediatR;

namespace Chronolibris.Application.Handlers.Shelves
{
    public class UpdateShelfCommandHandler : IRequestHandler<UpdateShelfCommand, Unit>
    {
        private readonly IUnitOfWork _uow;
        public UpdateShelfCommandHandler(IUnitOfWork uow)
        {
            _uow = uow;
        }
        public async Task<Unit> Handle(UpdateShelfCommand request, CancellationToken ct)
        {
            var shelf = await _uow.Shelves.GetByIdAsync(request.ShelfId, ct);

            if (shelf== null || shelf.UserId!=request.UserId)
            {
                throw new ChronolibrisException("Полка не найдена", ErrorType.NotFound);
            }

            if (shelf.ShelfTypeId != 3)
            {
                throw new ChronolibrisException("Системные полки нельзя переименовать", ErrorType.Validation);
            }

            shelf.Name = request.Name;
            await _uow.SaveChangesAsync(ct);
            return Unit.Value;
        }
    }
}
