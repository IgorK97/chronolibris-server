﻿using Chronolibris.Application.Models;
using Chronolibris.Application.Requests.Bookmarks;
using Chronolibris.Domain.Interfaces.Repository;
using MediatR;

namespace Chronolibris.Application.Handlers.Bookmarks
{
    public class GetBookmarksHandler(IBookmarkRepository bookmarkRepository) : IRequestHandler<GetBookmarksQuery, List<BookmarkDetails>>
    {

        public async Task<List<BookmarkDetails>> Handle(GetBookmarksQuery request, CancellationToken cancellationToken)
        {
            var bookmarks = await bookmarkRepository
                                            .GetAllForBookAndUserAsync(request.BookId, request.UserId, cancellationToken);

            return bookmarks.Select(b => new BookmarkDetails
            {
                Id = b.Id,
                Note = b.Note,
                BookFileId=b.BookFileId,
                Xpointer = b.Xpointer,
                CreatedAt = b.CreatedAt,
                Context = b.Context
            }).ToList();
        }
    }
}
