﻿namespace Chronolibris.Domain.Entities
{
    public class ContentParticipation
    {
        public long Id { get; set; }
        public long PersonId { get; set; }
        public Person Person { get; set; } = null!;
        public long PersonRoleId { get; set; }
        public PersonRole PersonRole { get; set; } = null!;
        public long ContentId { get; set; }
        public Content Content { get; set; } = null!;
    }
}
