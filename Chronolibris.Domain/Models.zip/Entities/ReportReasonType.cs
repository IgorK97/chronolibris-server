﻿using System.ComponentModel.DataAnnotations;

namespace Chronolibris.Domain.Entities
{
    public class ReportReasonType
    {
        public long Id { get; set; }
        [MaxLength(50)]
        public string Name { get; set; }
        public ICollection<Report> Reports { get; set; } = [];
    }
}
