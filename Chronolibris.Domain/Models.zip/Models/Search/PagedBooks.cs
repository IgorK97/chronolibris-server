﻿namespace Chronolibris.Domain.Models.Search
{
    public class PagedBooks<T>
    {
        public List<T> Items { get; set; } = [];
        public bool HasNext { get; set; }
        public long? LastId { get; set; }
        public double? LastBestSimilarity { get; set; }
    }
}
