﻿using Chronolibris.Domain.Entities;
using Chronolibris.Domain.Interfaces.Repository;
using Chronolibris.Infrastructure.Data;
using Chronolibris.Infrastructure.Persistance.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Chronolibris.Infrastructure.DataAccess.Persistance.Repositories
{
    public class ModerationTasksRepository : GenericRepository<ModerationTask>, IModerationTasksRepository
    {
        public ModerationTasksRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<ModerationTask?> GetLastTaskAsync(long targetId, long targetTypeId, CancellationToken token)
        {
            return await _context.ModerationTasks
                .Where(t => t.TargetId == targetId && t.TargetTypeId == targetTypeId)
                .OrderByDescending(t => t.StartedAt)
                .FirstOrDefaultAsync(token);
        }

        public async Task<ModerationTask?> GetActiveByTarget(long TargetId, long TargetTypeId, CancellationToken token = default)
        {
            return await _context.ModerationTasks.AsNoTracking().Where(t =>
            t.TargetId == TargetId &&
            t.TargetTypeId == TargetTypeId &&
            t.StatusId == 2
            ).FirstOrDefaultAsync(token);
        }

        public async Task<long?> TryCreateActiveTaskAsync(ModerationTask task, CancellationToken token) //написал так, тогда, если такая запись уже есть,
            //то будет не исключение, а просто нулл вернет
        {
            var sql = @"
                INSERT INTO moderation_tasks 
                    (target_id, target_type_id, moderated_by, started_at, status_id, comment)
                VALUES ({0}, {1}, {2}, {3}, {4}, {5})
                ON CONFLICT (target_id, target_type_id) WHERE status_id = 2 
                DO NOTHING
                RETURNING id;";

            var result = await _context.Database
                .SqlQueryRaw<long?>(sql,
                    task.TargetId, task.TargetTypeId, task.ModeratedBy,
                    task.StartedAt, task.StatusId, task.Comment)
                .ToListAsync(token);

            return result.FirstOrDefault();
        }
    }
}
